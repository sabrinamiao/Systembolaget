      <div id="adminHeader">
        <h2>Admin</h2>
        <p>You are logged in as <b><?php echo htmlspecialchars( $_SESSION['username']) ?></b>. <a href="admin.php?action=listArticles">Articles</a>   <a href="admin.php?action=listSortiments">Sortiments</a>  <a href="admin.php?action=listCategories">Categories</a> <a href="admin.php?action=logout"?>Log Out</a></p>
      </div>

